import React, { useState } from 'react';
import { useStore, getLocalDateString } from '../store/useStore';
import { FileDown, FileText } from 'lucide-react';
import jsPDF from 'jspdf';

export default function Reports() {
  const { patient, treatments, timeline, vitalSigns, documents } = useStore();
  const [selected, setSelected] = useState({
    personal: true,
    medication: true,
    vitals: true,
    timeline: false,
    documents: false
  });
  const [isGenerating, setIsGenerating] = useState(false);

  const toggle = (key: keyof typeof selected) => {
    setSelected(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const generatePDF = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const doc = new jsPDF();
      
      // Header
      doc.setFillColor(30, 58, 95); // Primary color
      doc.rect(0, 0, 210, 40, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(24);
      doc.text('CUIDA+', 20, 25);
      doc.setFontSize(12);
      doc.text('Reporte Clínico', 150, 25);
      
      let y = 50;
      doc.setTextColor(0, 0, 0);

      const checkPageBreak = (spaceNeeded: number) => {
        if (y + spaceNeeded > 280) {
          doc.addPage();
          y = 20;
        }
      };

      if (selected.personal) {
        checkPageBreak(50);
        doc.setFontSize(16);
        doc.text('Datos Personales y Médicos', 20, y);
        y += 10;
        doc.setFontSize(11);
        doc.text(`Paciente: ${patient.name} (${patient.age} años)`, 20, y); y += 7;
        doc.text(`Contacto: ${patient.mainContact} (${patient.mainContactPhone})`, 20, y); y += 7;
        doc.text(`Obra Social: ${patient.healthInsurance}`, 20, y); y += 7;
        doc.text(`Alergias: ${patient.allergies.join(', ') || 'Ninguna'}`, 20, y); y += 7;
        doc.text(`Diagnósticos: ${patient.diagnoses.join(', ')}`, 20, y); y += 15;
      }

      if (selected.medication) {
        checkPageBreak(30);
        doc.setFontSize(16);
        doc.text('Tratamientos Activos', 20, y);
        y += 10;
        doc.setFontSize(11);
        const activeT = treatments.filter(t => t.status === 'active');
        if (activeT.length === 0) {
          doc.text('Sin tratamientos activos.', 20, y); y += 7;
        } else {
          activeT.forEach(t => {
            checkPageBreak(15);
            doc.text(`• ${t.medicationName} ${t.presentation} - ${t.quantityPerDose} ${t.unit} (${t.frequency})`, 20, y);
            y += 7;
          });
        }
        y += 8;
      }

      if (selected.vitals) {
        checkPageBreak(40);
        doc.setFontSize(16);
        doc.text('Últimos Controles Vitales', 20, y);
        y += 10;
        doc.setFontSize(11);
        if (vitalSigns.length === 0) {
          doc.text('Sin registros.', 20, y); y += 7;
        } else {
          // Sort descending and take first 5
          const sortedVitals = [...vitalSigns].sort((a,b) => (b.date + b.time).localeCompare(a.date + a.time)).slice(0, 5);
          sortedVitals.forEach(v => {
            checkPageBreak(10);
            doc.text(`• ${v.date} ${v.time}: ${v.type} - ${v.value} ${v.unit}`, 20, y);
            y += 7;
          });
        }
        y += 8;
      }

      if (selected.timeline) {
        checkPageBreak(40);
        doc.setFontSize(16);
        doc.text('Historial Cronológico (Últimos 7 días)', 20, y);
        y += 10;
        doc.setFontSize(10);
        
        const todayStr = getLocalDateString();
        const parts = todayStr.split('-');
        const sevenDaysAgo = new Date(Number(parts[0]), Number(parts[1])-1, Number(parts[2]) - 7);
        const limitStr = `${sevenDaysAgo.getFullYear()}-${String(sevenDaysAgo.getMonth()+1).padStart(2,'0')}-${String(sevenDaysAgo.getDate()).padStart(2,'0')}`;
        
        const recentEvents = timeline.filter(t => t.date >= limitStr).sort((a,b) => (b.date + b.time).localeCompare(a.date + a.time));
        
        if (recentEvents.length === 0) {
          doc.text('Sin registros en el período.', 20, y); y += 7;
        } else {
          recentEvents.forEach(e => {
            checkPageBreak(10);
            doc.text(`[${e.date} ${e.time}] ${e.title} - ${e.user}`, 20, y); y += 5;
            doc.text(`  ${e.description.substring(0, 100)}`, 20, y); y += 7;
          });
        }
      }

      if (selected.documents) {
        checkPageBreak(40);
        doc.setFontSize(16);
        doc.text('Documentos y Estudios Clínicos', 20, y);
        y += 10;
        doc.setFontSize(10);
        
        if (documents.length === 0) {
          doc.text('Sin registros.', 20, y); y += 7;
        } else {
          documents.forEach(d => {
            checkPageBreak(10);
            doc.text(`• ${d.date} | ${d.name} (${d.category}) - Dr/a. ${d.professional}`, 20, y); y += 5;
            if (d.description) {
              doc.text(`  Desc: ${d.description}`, 20, y); y += 7;
            } else {
              y += 2;
            }
          });
        }
      }

      // Footer - page numbers
      const pageCount = (doc.internal as any).getNumberOfPages();
      for(let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(10);
        doc.setTextColor(150, 150, 150);
        doc.text(`Paciente: ${patient.name} | Generado: ${getLocalDateString()} | Pág. ${i}/${pageCount}`, 20, 290);
      }

      doc.save(`Reporte_${patient.name.replace(' ', '_')}.pdf`);
      setIsGenerating(false);
    }, 1500);
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <header>
        <h2 className="text-2xl font-bold text-gray-900">Generar Informe</h2>
        <p className="text-gray-500">Selecciona los datos a incluir en el reporte PDF</p>
      </header>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 md:p-8">
        <div className="space-y-4 mb-8">
          {[
            { id: 'personal', title: 'Datos Personales y Médicos', desc: 'Alergias, diagnósticos, contactos.' },
            { id: 'medication', title: 'Medicación Actual', desc: 'Tratamientos activos y posología.' },
            { id: 'vitals', title: 'Controles Vitales', desc: 'Últimos registros de signos vitales.' },
            { id: 'timeline', title: 'Historial Cronológico (Últimos 7 días)', desc: 'Eventos, incidentes, turnos reales, tomas.' },
            { id: 'documents', title: 'Documentos y Estudios', desc: 'Metadatos de documentos.' },
          ].map(opt => (
            <label key={opt.id} className={`flex items-center p-4 rounded-xl border cursor-pointer transition-colors ${selected[opt.id as keyof typeof selected] ? 'bg-primary/5 border-primary' : 'bg-white border-gray-200'}`}>
              <input 
                type="checkbox" 
                className="w-5 h-5 mr-4 accent-primary" 
                checked={selected[opt.id as keyof typeof selected]} 
                onChange={() => toggle(opt.id as keyof typeof selected)} 
              />
              <div>
                <p className={`font-bold ${selected[opt.id as keyof typeof selected] ? 'text-primary' : 'text-gray-900'}`}>{opt.title}</p>
                <p className="text-sm text-gray-500">{opt.desc}</p>
              </div>
            </label>
          ))}
        </div>

        <button 
          onClick={generatePDF}
          disabled={isGenerating || !Object.values(selected).some(v => v)}
          className="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg hover:bg-primary-light transition-colors flex items-center justify-center disabled:opacity-50"
        >
          {isGenerating ? 'Generando PDF...' : (
            <>
              <FileDown className="w-6 h-6 mr-2" />
              GENERAR PDF
            </>
          )}
        </button>
      </div>
    </div>
  );
}
