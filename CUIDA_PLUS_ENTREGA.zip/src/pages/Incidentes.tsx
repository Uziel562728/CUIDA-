import React, { useState } from 'react';
import { useStore, getLocalDateString, getLocalTimeString } from '../store/useStore';
import { AlertTriangle, Plus } from 'lucide-react';

export default function Incidentes() {
  const { incidents, addIncident, currentUser } = useStore();
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ type: 'Caída', description: '', actions: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addIncident({
      id: Date.now().toString(),
      date: getLocalDateString(),
      time: getLocalTimeString(),
      type: form.type,
      description: form.description,
      actions: form.actions,
      registeredBy: currentUser?.name || 'Sistema',
      status: 'reported',
      history: [{ date: getLocalDateString(), time: getLocalTimeString(), status: 'reported', user: currentUser?.name || 'Sistema' }]
    });
    setShowModal(false);
    setForm({ type: 'Caída', description: '', actions: '' });
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Registro de Incidentes</h2>
          <p className="text-gray-500">Historial y seguimiento</p>
        </div>
        <button onClick={() => setShowModal(true)} className="bg-danger text-white px-4 py-2 rounded-lg flex items-center font-bold hover:bg-red-700">
          <Plus className="w-5 h-5 mr-1" /> Nuevo
        </button>
      </header>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold mb-4">Registrar Incidente</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Tipo de incidente</label>
                <select className="w-full border rounded-lg p-2" value={form.type} onChange={e => setForm({...form, type: e.target.value})}>
                  <option>Caída</option>
                  <option>Mareo/Desmayo</option>
                  <option>Error en medicación</option>
                  <option>Otro</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Descripción</label>
                <textarea required className="w-full border rounded-lg p-2 h-20" value={form.description} onChange={e => setForm({...form, description: e.target.value})}></textarea>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Acciones tomadas</label>
                <textarea required className="w-full border rounded-lg p-2 h-20" value={form.actions} onChange={e => setForm({...form, actions: e.target.value})}></textarea>
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 text-gray-600">Cancelar</button>
                <button type="submit" className="px-4 py-2 bg-danger text-white rounded-lg">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {incidents.length === 0 && <p className="text-gray-500 py-8 text-center bg-white rounded-xl border">No hay incidentes registrados.</p>}
        {incidents.map(inc => (
          <div key={inc.id} className="bg-white rounded-xl p-5 border border-red-100 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-2 h-full bg-danger"></div>
            <div className="flex justify-between mb-2 pl-4">
              <h3 className="font-bold text-gray-900 text-lg flex items-center"><AlertTriangle className="w-5 h-5 text-danger mr-2"/> {inc.type}</h3>
              <span className="text-sm text-gray-500 font-medium">{inc.date} {inc.time}</span>
            </div>
            <div className="pl-4 space-y-2 text-sm text-gray-700">
              <p><strong>Descripción:</strong> {inc.description}</p>
              <p><strong>Acciones:</strong> {inc.actions}</p>
              <p className="text-xs text-gray-500 mt-2">Registrado por: {inc.registeredBy}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
