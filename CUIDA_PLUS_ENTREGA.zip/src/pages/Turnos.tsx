import React, { useState } from 'react';
import { useStore, getLocalDateString, getLocalTimeString } from '../store/useStore';
import { Calendar, CheckCircle, Clock } from 'lucide-react';

export default function Turnos() {
  const { shifts, startShift, endShift, currentUser } = useStore();
  const [report, setReport] = useState('');
  const [showEndModal, setShowEndModal] = useState(false);
  const [activeShiftId, setActiveShiftId] = useState<string | null>(null);

  const handleStart = () => {
    if (!currentUser) return;
    startShift({
      id: Date.now().toString(),
      userId: currentUser.id,
      userName: currentUser.name,
      role: currentUser.role,
      date: getLocalDateString(),
      startTime: getLocalTimeString(),
      status: 'active'
    });
  };

  const handleEnd = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeShiftId) {
      endShift(activeShiftId, report);
      setShowEndModal(false);
      setReport('');
    }
  };

  const activeShift = shifts.find(s => s.status === 'active' && s.userId === currentUser?.id);

  return (
    <div className="space-y-6">
      <header>
        <h2 className="text-2xl font-bold text-gray-900">Turnos de Enfermería</h2>
        <p className="text-gray-500">Gestión de jornada laboral</p>
      </header>

      {(currentUser?.role === 'nurse' || currentUser?.role === 'admin') && (
        <div className="bg-white rounded-xl shadow-sm border p-6 text-center">
          {activeShift ? (
            <div>
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-4">
                <Clock className="w-8 h-8 animate-pulse" />
              </div>
              <h3 className="text-xl font-bold mb-2">Turno en curso</h3>
              <p className="text-gray-500 mb-6">Iniciado hoy a las {activeShift.startTime}</p>
              <button 
                onClick={() => { setActiveShiftId(activeShift.id); setShowEndModal(true); }}
                className="bg-danger text-white px-8 py-3 rounded-lg font-bold w-full md:w-auto"
              >
                FINALIZAR TURNO
              </button>
            </div>
          ) : (
            <div>
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 text-gray-400 mb-4">
                <Calendar className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-6">No hay turno activo</h3>
              <button 
                onClick={handleStart}
                className="bg-primary text-white px-8 py-3 rounded-lg font-bold w-full md:w-auto"
              >
                INICIAR TURNO
              </button>
            </div>
          )}
        </div>
      )}

      {showEndModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold mb-4">Finalizar Turno</h3>
            <form onSubmit={handleEnd} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Parte y observaciones del turno</label>
                <textarea 
                  required 
                  className="w-full border rounded-lg p-2 h-32" 
                  placeholder="Estado general, alimentación, higiene..."
                  value={report} 
                  onChange={e => setReport(e.target.value)} 
                ></textarea>
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button type="button" onClick={() => setShowEndModal(false)} className="px-4 py-2 text-gray-600">Cancelar</button>
                <button type="submit" className="px-4 py-2 bg-danger text-white rounded-lg">Guardar y Finalizar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div>
        <h3 className="font-bold text-gray-900 mb-4">Historial de Turnos</h3>
        <div className="space-y-3">
          {shifts.map(s => (
            <div key={s.id} className="bg-white rounded-xl p-4 border flex justify-between items-center">
              <div>
                <p className="font-bold">{s.userName}</p>
                <p className="text-sm text-gray-500">{s.date} • {s.startTime} - {s.endTime || 'Actual'}</p>
              </div>
              <div>
                {s.status === 'completed' ? (
                  <span className="flex items-center text-xs font-medium text-health bg-health/10 px-2 py-1 rounded-full"><CheckCircle className="w-3 h-3 mr-1"/> Completado</span>
                ) : (
                  <span className="flex items-center text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-full"><Clock className="w-3 h-3 mr-1"/> Activo</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
