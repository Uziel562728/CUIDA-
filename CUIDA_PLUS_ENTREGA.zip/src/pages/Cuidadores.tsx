import React from 'react';
import { useStore } from '../store/useStore';
import { Users, Phone } from 'lucide-react';

export default function Cuidadores() {
  const { caregivers } = useStore();

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Equipo de Cuidado</h2>
          <p className="text-gray-500">Gestión de enfermeros y cuidadores</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {caregivers.map(c => (
          <div key={c.id} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 flex items-start space-x-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-lg">
              {c.name.charAt(0)}
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-900 text-lg">{c.name}</h3>
              <p className="text-primary text-sm font-medium mb-2">{c.role}</p>
              <p className="text-sm text-gray-600"><strong>Días:</strong> {c.days}</p>
              <p className="text-sm text-gray-600 mb-3"><strong>Horario:</strong> {c.schedule}</p>
              <button className="flex items-center text-sm font-medium text-gray-600 hover:text-primary transition-colors">
                <Phone className="w-4 h-4 mr-1" /> Llamar {c.phone}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
