import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { ShoppingCart, Trash2, ArrowRight, CheckCircle, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Cart() {
  const { cart, removeFromCart, clearCart, placeOrder, providers } = useStore();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('tarjeta_demo');

  const totalItems = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const shipping = totalItems > 0 ? 2000 : 0;
  const finalTotal = totalItems + shipping;

  const provider = cart.length > 0 ? providers.find(p => p.id === cart[0].providerId) : null;

  const handleCheckout = () => {
    setIsProcessing(true);
    setTimeout(() => {
      placeOrder(paymentMethod);
      setIsProcessing(false);
      setIsSuccess(true);
    }, 2000);
  };

  const handleClear = () => {
    if (confirm('¿Seguro que deseas vaciar el carrito?')) {
      clearCart();
    }
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="w-20 h-20 bg-health/20 rounded-full flex items-center justify-center mb-6">
          <CheckCircle className="w-10 h-10 text-health" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">PAGO DE DEMOSTRACIÓN APROBADO</h2>
        <p className="text-gray-500 mb-8 text-center max-w-md">Tu pedido simulado ha sido procesado correctamente y ya fue enviado al proveedor.</p>
        <button 
          onClick={() => navigate('/pedidos')}
          className="bg-primary text-white px-8 py-3 rounded-xl font-medium hover:bg-primary-light transition-colors"
        >
          Ver mis pedidos
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <header className="flex items-center justify-between">
        <div className="flex items-center">
          <button onClick={() => navigate(-1)} className="mr-4 text-gray-400 hover:text-gray-900">
            ← Volver
          </button>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <ShoppingCart className="w-6 h-6 mr-2" />
            Carrito
          </h2>
        </div>
        {cart.length > 0 && (
          <button onClick={handleClear} className="text-danger hover:text-red-700 text-sm font-medium">Vaciar carrito</button>
        )}
      </header>

      {cart.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-gray-100">
          <ShoppingCart className="w-16 h-16 text-gray-200 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">Tu carrito está vacío</h3>
          <p className="text-gray-500 mb-6">Aún no has agregado ningún producto.</p>
          <button 
            onClick={() => navigate('/marketplace')}
            className="bg-primary text-white px-6 py-2 rounded-lg font-medium hover:bg-primary-light transition-colors"
          >
            Ir al Marketplace
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-info/10 text-info p-4 rounded-xl flex items-start border border-info/20">
              <AlertCircle className="w-5 h-5 mr-2 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-bold">Proveedor actual: {provider?.name}</p>
                <p>Solo puedes comprar de un proveedor a la vez. Si deseas cambiar, debes vaciar el carrito.</p>
              </div>
            </div>

            {cart.map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-4 border border-gray-100 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-gray-900">{item.name}</h4>
                  <p className="text-sm text-gray-500">Cant: {item.quantity} paq. ({item.quantity * item.unitsPerPackage} unid.)</p>
                </div>
                <div className="flex items-center space-x-6">
                  <span className="font-bold text-gray-900">${(item.price * item.quantity).toLocaleString('es-AR')}</span>
                  <button onClick={() => removeFromCart(item.productId)} className="text-red-400 hover:text-red-600">
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100 h-fit">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Resumen de compra</h3>
            
            <div className="space-y-3 mb-6 pb-6 border-b border-gray-100">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>${totalItems.toLocaleString('es-AR')}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Envío ({provider?.name})</span>
                <span>${shipping.toLocaleString('es-AR')}</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center mb-6">
              <span className="text-lg font-bold text-gray-900">TOTAL</span>
              <span className="text-2xl font-bold text-primary">${finalTotal.toLocaleString('es-AR')}</span>
            </div>

            <div className="mb-6 space-y-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Método de pago (Simulado)</label>
              <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)} className="w-full border border-gray-300 rounded-lg p-2 text-sm focus:ring-primary focus:border-primary">
                <option value="tarjeta_demo">Tarjeta de Crédito (Demo)</option>
                <option value="mercadopago_demo">Mercado Pago (Demo)</option>
                <option value="transferencia_demo">Transferencia (Demo)</option>
              </select>
            </div>

            <button 
              onClick={handleCheckout}
              disabled={isProcessing}
              className="w-full bg-health text-white py-3 rounded-xl font-bold text-lg hover:bg-health-light transition-colors flex items-center justify-center disabled:opacity-70"
            >
              {isProcessing ? 'Procesando...' : (
                <>Confirmar Pago <ArrowRight className="w-5 h-5 ml-2" /></>
              )}
            </button>
            <p className="text-xs text-gray-400 text-center mt-4">
              * Operación 100% simulada. No requiere datos reales.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
