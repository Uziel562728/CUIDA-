import React, { useState } from 'react';
import { useStore, getLocalDateString } from '../store/useStore';
import { CalendarClock, CheckCircle, Circle, Plus } from 'lucide-react';
import { Reminder } from '../types';

export default function Recordatorios() {
  const { reminders, addReminder, completeReminder } = useStore();
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ title: '', type: 'general', time: '10:00' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title) return;
    addReminder({
      id: Date.now().toString(),
      title: form.title,
      type: form.type as any,
      date: getLocalDateString(),
      time: form.time,
      repeat: 'once',
      status: 'pending'
    });
    setShowModal(false);
    setForm({ title: '', type: 'general', time: '10:00' });
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Recordatorios</h2>
          <p className="text-gray-500">Agenda diaria de tareas</p>
        </div>
        <button onClick={() => setShowModal(true)} className="bg-primary text-white px-4 py-2 rounded-lg flex items-center">
          <Plus className="w-5 h-5 mr-1" /> Nuevo
        </button>
      </header>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 className="text-xl font-bold mb-4">Nuevo Recordatorio</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Título</label>
                <input required type="text" className="w-full border rounded-lg p-2" value={form.title} onChange={e => setForm({...form, title: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Hora</label>
                <input required type="time" className="w-full border rounded-lg p-2" value={form.time} onChange={e => setForm({...form, time: e.target.value})} />
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 text-gray-600">Cancelar</button>
                <button type="submit" className="px-4 py-2 bg-primary text-white rounded-lg">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {reminders.filter(r => r.date === getLocalDateString()).length === 0 && (
          <p className="text-gray-500 text-center py-8">No hay recordatorios para hoy.</p>
        )}
        {reminders.filter(r => r.date === getLocalDateString()).sort((a,b) => a.time.localeCompare(b.time)).map(r => (
          <div key={r.id} className={`bg-white rounded-xl p-4 flex items-center justify-between border ${r.status === 'completed' ? 'opacity-60' : ''}`}>
            <div className="flex items-center">
              <button onClick={() => r.status === 'pending' && completeReminder(r.id)} className="mr-3 text-primary">
                {r.status === 'completed' ? <CheckCircle className="w-6 h-6" /> : <Circle className="w-6 h-6" />}
              </button>
              <div>
                <p className={`font-bold ${r.status === 'completed' ? 'line-through text-gray-500' : 'text-gray-900'}`}>{r.title}</p>
                <p className="text-sm text-gray-500">{r.time}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
