import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  User, Patient, Product, Treatment, Dose, TimelineEvent, 
  Shift, Incident, VitalSign, Provider, Order, CartItem, DocumentRecord, Caregiver, Reminder
} from '../types';

// Helper to get local date string YYYY-MM-DD in Argentina
export const getLocalDateString = () => {
  const d = new Date(new Date().toLocaleString("en-US", { timeZone: "America/Argentina/Buenos_Aires" }));
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

// Helper to get local time string HH:mm in Argentina
export const getLocalTimeString = () => {
  const d = new Date(new Date().toLocaleString("en-US", { timeZone: "America/Argentina/Buenos_Aires" }));
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
};

interface AppState {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  resetDemoData: () => void;
  
  patient: Patient;
  updatePatient: (patient: Partial<Patient>) => void;
  
  products: Product[];
  updateProductStock: (id: string, qty: number, reason: string, user: string) => void;
  
  treatments: Treatment[];
  addTreatment: (t: Treatment) => void;
  updateTreatment: (id: string, updates: Partial<Treatment>) => void;
  
  doses: Dose[];
  generateDosesForDay: (date: string) => void;
  logDose: (id: string, status: 'taken' | 'missed', user: string, obs?: string) => void;
  
  timeline: TimelineEvent[];
  addTimelineEvent: (event: TimelineEvent) => void;
  
  shifts: Shift[];
  caregivers: Caregiver[];
  startShift: (shift: Shift) => void;
  endShift: (id: string, report: string) => void;
  
  incidents: Incident[];
  addIncident: (incident: Incident) => void;
  updateIncidentState: (id: string, status: Incident['status'], note: string, user: string) => void;
  
  vitalSigns: VitalSign[];
  addVitalSign: (vital: VitalSign) => void;
  
  providers: Provider[];
  
  orders: Order[];
  cart: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  placeOrder: (method: string) => void;
  updateOrderStatus: (id: string, status: Order['status'], user: string) => void;
  
  documents: DocumentRecord[];
  addDocument: (doc: DocumentRecord) => void;

  reminders: Reminder[];
  addReminder: (rem: Reminder) => void;
  completeReminder: (id: string) => void;

  updateProviderProduct: (providerId: string, productId: string, updates: any) => void;
}

const initialPatient: Patient = {
  id: 'p1',
  name: 'Juan Pérez',
  age: 78,
  birthDate: '1948-05-12',
  address: 'Av. Siempre Viva 742, CABA',
  mainContact: 'Martín Pérez',
  mainContactPhone: '11-1234-5678',
  emergencyContact: 'Laura Pérez',
  emergencyContactPhone: '11-8765-4321',
  doctor: 'Dr. Carlos Gómez',
  healthInsurance: 'OSDE',
  bloodType: 'A+',
  allergies: ['Penicilina', 'Ibuprofeno'],
  diagnoses: ['Hipertensión arterial', 'Diabetes tipo 2', 'Artrosis leve'],
  observations: 'Paciente independiente para actividades básicas pero requiere asistencia para el baño. Presenta mareos ocasionales al levantarse rápido.'
};

const initialProducts: Product[] = [
  { id: 'pr1', name: 'Pañales talle G', category: 'diapers', currentQuantity: 20, unit: 'unidades', dailyConsumption: 5, minStock: 15 },
  { id: 'pr6', name: 'Losartán 50mg', category: 'medication', currentQuantity: 12, unit: 'comprimidos', dailyConsumption: 1, minStock: 10 },
  { id: 'pr7', name: 'Metformina 850mg', category: 'medication', currentQuantity: 20, unit: 'comprimidos', dailyConsumption: 2, minStock: 10 },
];

const initialTreatments: Treatment[] = [
  { 
    id: 't1', patientId: 'p1', productId: 'pr6', medicationName: 'Losartán', presentation: '50mg', 
    quantityPerDose: 1, unit: 'comprimido', frequency: 'Cada 24 horas', schedules: ['08:00'], 
    repeatDays: [0,1,2,3,4,5,6], startDate: '2026-08-10', indications: 'Tomar con el desayuno', 
    professional: 'Dr. Carlos Gómez', status: 'active' 
  },
  { 
    id: 't2', patientId: 'p1', productId: 'pr7', medicationName: 'Metformina', presentation: '850mg', 
    quantityPerDose: 1, unit: 'comprimido', frequency: 'Cada 12 horas', schedules: ['08:00', '20:00'], 
    repeatDays: [0,1,2,3,4,5,6], startDate: '2025-01-15', indications: 'Con las comidas principales', 
    professional: 'Dr. Carlos Gómez', status: 'active' 
  },
];

const initialProviders: Provider[] = [
  {
    id: 'prov1',
    name: 'Farmacia Central',
    email: 'contacto@farmaciacentral.com',
    products: [
      { productId: 'pr6', name: 'Losartán', presentation: '50mg Caja x30', unitsPerPackage: 30, price: 12500, stock: 'available', delivery: 'Hoy' },
      { productId: 'pr1', name: 'Pañales talle G', presentation: 'Bolsa x16', unitsPerPackage: 16, price: 12000, stock: 'available', delivery: 'Hoy' },
      { productId: 'pr7', name: 'Metformina', presentation: '850mg Caja x30', unitsPerPackage: 30, price: 9000, stock: 'available', delivery: 'Hoy' }
    ]
  },
  {
    id: 'prov2',
    name: 'Farmacia Norte',
    email: 'ventas@farmacianorte.com',
    products: [
      { productId: 'pr6', name: 'Losartán', presentation: '50mg Caja x30', unitsPerPackage: 30, price: 11900, stock: 'available', delivery: 'Mañana' },
      { productId: 'pr1', name: 'Pañales talle G', presentation: 'Bolsa x16', unitsPerPackage: 16, price: 11500, stock: 'available', delivery: 'Mañana' }
    ]
  }
];

const initialState = {
  patient: initialPatient,
  products: initialProducts,
  treatments: initialTreatments,
  doses: [] as Dose[],
  timeline: [] as TimelineEvent[],
  shifts: [] as Shift[],
  caregivers: [
    { id: 'c1', name: 'María González', role: 'Enfermera', phone: '11-1111-2222', schedule: '08:00 - 20:00', days: 'Lun a Vie' },
    { id: 'c2', name: 'Laura Rodríguez', role: 'Enfermera', phone: '11-3333-4444', schedule: '20:00 - 08:00', days: 'Lun a Vie' }
  ],
  incidents: [] as Incident[],
  vitalSigns: [] as VitalSign[],
  providers: initialProviders,
  orders: [] as Order[],
  cart: [] as CartItem[],
  documents: [] as DocumentRecord[],
  reminders: [] as Reminder[],
};

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      setCurrentUser: (user) => set({ currentUser: user }),
      resetDemoData: () => set({ ...initialState, doses: [] }),

      ...initialState,

      updatePatient: (updates) => set((state) => ({ patient: { ...state.patient, ...updates } })),

      updateProductStock: (id, qty, reason, user) => set((state) => {
        const product = state.products.find(p => p.id === id);
        if (!product) return state;
        const diff = qty - product.currentQuantity;
        if (diff === 0) return state;

        const event: TimelineEvent = {
          id: Date.now().toString() + Math.random(),
          date: getLocalDateString(),
          time: getLocalTimeString(),
          type: 'stock',
          title: 'Ajuste de inventario',
          description: `${product.name}: ${diff > 0 ? '+' : ''}${diff} ${product.unit}. Motivo: ${reason}`,
          user: user
        };

        return {
          products: state.products.map(p => p.id === id ? { ...p, currentQuantity: qty } : p),
          timeline: [event, ...state.timeline]
        };
      }),

      addTreatment: (t) => set((state) => ({ treatments: [...state.treatments, t] })),
      updateTreatment: (id, updates) => set((state) => ({ 
        treatments: state.treatments.map(t => t.id === id ? { ...t, ...updates } : t) 
      })),

      generateDosesForDay: (date) => set((state) => {
        // Idempotent: only generate if not already generated for this date
        const existingForDate = state.doses.filter(d => d.date === date);
        const newDoses: Dose[] = [];
        const dateObj = new Date(date + 'T00:00:00');
        const dayOfWeek = dateObj.getDay();

        state.treatments.forEach(t => {
          if (t.status === 'active' && t.repeatDays.includes(dayOfWeek)) {
            // Check start and end dates
            if (t.startDate && date < t.startDate) return;
            if (t.endDate && date > t.endDate) return;
            
            t.schedules.forEach(time => {
              const doseId = `${t.id}-${date}-${time}`;
              if (!existingForDate.find(d => d.id === doseId)) {
                newDoses.push({
                  id: doseId,
                  treatmentId: t.id,
                  date,
                  scheduledTime: time,
                  status: 'pending'
                });
              }
            });
          }
        });

        if (newDoses.length === 0) return state;
        return { doses: [...state.doses, ...newDoses] };
      }),

      logDose: (id, status, user, obs) => set((state) => {
        const dose = state.doses.find(d => d.id === id);
        if (!dose || dose.status !== 'pending') return state; // Validar que esté pendiente

        const treatment = state.treatments.find(t => t.id === dose.treatmentId);
        if (!treatment) return state;

        let updatedProducts = state.products;
        let event: TimelineEvent | null = null;

        if (status === 'taken') {
          const product = state.products.find(p => p.id === treatment.productId);
          if (!product) return state; // Must have product linked
          const newQty = product.currentQuantity - treatment.quantityPerDose;
          if (newQty < 0) return state; // Inventario insuficiente prevent
          updatedProducts = state.products.map(p => p.id === product.id ? { ...p, currentQuantity: newQty } : p);

          event = {
            id: Date.now().toString() + Math.random(),
            date: getLocalDateString(),
            time: getLocalTimeString(),
            type: 'medication',
            title: 'Medicación administrada',
            description: `${treatment.medicationName} ${treatment.presentation} administrado.`,
            user: user
          };
        } else if (status === 'missed') {
          event = {
            id: Date.now().toString() + Math.random(),
            date: getLocalDateString(),
            time: getLocalTimeString(),
            type: 'medication',
            title: 'Medicación omitida',
            description: `${treatment.medicationName} no administrado. Motivo: ${obs || 'No especificado'}`,
            user: user
          };
        }

        const newTimeline = event ? [event, ...state.timeline] : state.timeline;

        return {
          doses: state.doses.map(d => d.id === id ? { ...d, status, actualTime: getLocalTimeString(), registeredBy: user, observations: obs } : d),
          products: updatedProducts,
          timeline: newTimeline
        };
      }),

      addTimelineEvent: (event) => set((state) => ({ timeline: [event, ...state.timeline] })),

      startShift: (shift) => set((state) => {
        // Prevent double start for same user on same day/time roughly (simplified)
        if (state.shifts.some(s => s.userId === shift.userId && s.status === 'active')) return state;
        
        const event: TimelineEvent = {
          id: Date.now().toString() + Math.random(),
          date: getLocalDateString(),
          time: getLocalTimeString(),
          type: 'shift',
          title: 'Turno iniciado',
          description: `${shift.userName} inició turno.`,
          user: shift.userName
        };
        return { shifts: [...state.shifts, shift], timeline: [event, ...state.timeline] };
      }),

      endShift: (id, report) => set((state) => {
        const shift = state.shifts.find(s => s.id === id);
        if (!shift || shift.status === 'completed') return state;

        const event: TimelineEvent = {
          id: Date.now().toString() + Math.random(),
          date: getLocalDateString(),
          time: getLocalTimeString(),
          type: 'shift',
          title: 'Turno finalizado',
          description: `${shift.userName} finalizó turno. Parte: ${report.substring(0,50)}...`,
          user: shift.userName
        };
        return {
          shifts: state.shifts.map(s => s.id === id ? { ...s, status: 'completed', endTime: getLocalTimeString(), report } : s),
          timeline: [event, ...state.timeline]
        };
      }),

      addIncident: (incident) => set((state) => {
        const event: TimelineEvent = {
          id: Date.now().toString() + Math.random(),
          date: incident.date,
          time: incident.time,
          type: 'incident',
          title: `Incidente: ${incident.type}`,
          description: incident.description,
          user: incident.registeredBy
        };
        return { incidents: [incident, ...state.incidents], timeline: [event, ...state.timeline] };
      }),

      updateIncidentState: (id, status, note, user) => set((state) => {
        const incident = state.incidents.find(i => i.id === id);
        if (!incident) return state;

        const newHistoryItem = { date: getLocalDateString(), time: getLocalTimeString(), status, user, note };
        const event: TimelineEvent = {
          id: Date.now().toString() + Math.random(),
          date: getLocalDateString(),
          time: getLocalTimeString(),
          type: 'incident',
          title: `Seguimiento de incidente`,
          description: `Estado: ${status}. Nota: ${note}`,
          user: user
        };

        return {
          incidents: state.incidents.map(i => i.id === id ? { ...i, status, history: [...i.history, newHistoryItem] } : i),
          timeline: [event, ...state.timeline]
        };
      }),

      addVitalSign: (vital) => set((state) => {
        const event: TimelineEvent = {
          id: Date.now().toString() + Math.random(),
          date: vital.date,
          time: vital.time,
          type: 'control',
          title: 'Control registrado',
          description: `${vital.type}: ${vital.value} ${vital.unit}`,
          user: vital.registeredBy
        };
        return { vitalSigns: [vital, ...state.vitalSigns], timeline: [event, ...state.timeline] };
      }),

      addToCart: (item) => set((state) => {
        // Enforce single provider policy
        if (state.cart.length > 0 && state.cart[0].providerId !== item.providerId) {
          throw new Error('MULTIPLE_PROVIDERS');
        }
        // Group identical items
        const existingIdx = state.cart.findIndex(c => c.productId === item.productId);
        if (existingIdx >= 0) {
          const newCart = [...state.cart];
          newCart[existingIdx].quantity += item.quantity;
          return { cart: newCart };
        }
        return { cart: [...state.cart, item] };
      }),
      removeFromCart: (productId) => set((state) => ({ cart: state.cart.filter(c => c.productId !== productId) })),
      clearCart: () => set({ cart: [] }),

      placeOrder: (method) => set((state) => {
        if (state.cart.length === 0) return state;
        
        const totalItems = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const shipping = 2000;
        const total = totalItems + shipping;
        const provider = state.providers.find(p => p.id === state.cart[0].providerId);

        const newOrder: Order = {
          id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
          date: getLocalDateString(),
          time: getLocalTimeString(),
          providerId: state.cart[0].providerId,
          providerName: provider?.name || 'Proveedor',
          items: [...state.cart],
          total,
          status: 'paid', // simulated payment
          history: [{ status: 'paid', date: getLocalDateString(), time: getLocalTimeString(), user: state.currentUser?.name || 'Sistema' }]
        };

        const event: TimelineEvent = {
          id: Date.now().toString() + Math.random(),
          date: getLocalDateString(),
          time: getLocalTimeString(),
          type: 'order',
          title: 'Pedido realizado',
          description: `Pedido a ${newOrder.providerName} por $${total.toLocaleString('es-AR')}. Método: ${method}`,
          user: state.currentUser?.name || 'Usuario'
        };

        return { orders: [newOrder, ...state.orders], cart: [], timeline: [event, ...state.timeline] };
      }),

      updateOrderStatus: (id, status, user) => set((state) => {
        const order = state.orders.find(o => o.id === id);
        if (!order || order.status === status) return state;
        if (order.status === 'delivered') return state; // Terminal state

        let updatedProducts = state.products;
        let eventDesc = `Estado de pedido #${order.id} actualizado a ${status}.`;

        // Replenish stock EXACTLY ONCE when delivered
        if (status === 'delivered') {
          updatedProducts = [...state.products];
          order.items.forEach(item => {
            const prodIdx = updatedProducts.findIndex(p => p.id === item.productId);
            if (prodIdx >= 0) {
              updatedProducts[prodIdx] = {
                ...updatedProducts[prodIdx],
                currentQuantity: updatedProducts[prodIdx].currentQuantity + (item.unitsPerPackage * item.quantity)
              };
            }
          });
          eventDesc = `Pedido #${order.id} entregado. Stock reabastecido.`;
        }

        const newHistoryItem = { status, date: getLocalDateString(), time: getLocalTimeString(), user };
        const event: TimelineEvent = {
          id: Date.now().toString() + Math.random(),
          date: getLocalDateString(),
          time: getLocalTimeString(),
          type: 'order',
          title: 'Actualización de Pedido',
          description: eventDesc,
          user: user
        };

        return {
          orders: state.orders.map(o => o.id === id ? { ...o, status, history: [...o.history, newHistoryItem] } : o),
          products: updatedProducts,
          timeline: [event, ...state.timeline]
        };
      }),

      addDocument: (doc) => set((state) => ({ documents: [doc, ...state.documents] })),
      
      addReminder: (rem) => set((state) => ({ reminders: [...state.reminders, rem] })),
      completeReminder: (id) => set((state) => ({
        reminders: state.reminders.map(r => r.id === id ? { ...r, status: 'completed' } : r)
      })),

      updateProviderProduct: (providerId, productId, updates) => set((state) => ({
        providers: state.providers.map(prov => prov.id === providerId ? {
          ...prov,
          products: prov.products.map(prod => prod.productId === productId ? { ...prod, ...updates } : prod)
        } : prov)
      })),

    }),
    {
      name: 'cuida-plus-storage', // unique name
      version: 1, // versioning
    }
  )
);
